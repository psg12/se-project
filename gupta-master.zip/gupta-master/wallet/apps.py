from django.apps import AppConfig


class WalletConfig(AppConfig):
    name = 'wallet'
